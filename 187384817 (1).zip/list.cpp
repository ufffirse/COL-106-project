#include "list.h"
List::List(){
    size = 0;

    sentinel_head = new Node(true);
    sentinel_tail = new Node(true);

    sentinel_head->next = sentinel_tail;
    sentinel_tail->prev = sentinel_head;
}


List::~List() {
    Node* x = sentinel_head->next;
    delete sentinel_head;
    while (!x->is_sentinel_node()) {
        Node* temp = x;
        x = x->next;
        delete temp;
    }
    delete sentinel_tail;
}

void List::insert(int v) {
    Node* nd = new Node(v, nullptr, nullptr);
    sentinel_tail->prev->next = nd;
    nd->prev = sentinel_tail->prev;
    nd->next = sentinel_tail;
    sentinel_tail->prev = nd;

    size += 1; 
}


int  List::delete_tail(){
    int x= sentinel_tail->prev->get_value();
    sentinel_tail->prev->prev->next=sentinel_tail;
    delete sentinel_tail->prev;
    sentinel_tail->prev=sentinel_tail->prev->prev;
    size-=1;
    return x;
}

int List::get_size(){
    int x=0;
    Node* y=sentinel_head;
    while(!(y->next->is_sentinel_node())){
        x=x+1;
        y = y->next;
    }
    return x;
}

Node* List::get_head(){
    return sentinel_head;
}

