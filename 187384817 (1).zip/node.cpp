#include "node.h" 
 
 Node::Node(bool is_sentinel){
        this->next=nullptr;
        this->prev=nullptr;
        this->is_sentinel=is_sentinel;
    }

    // Use to construct a regular node
    Node::Node(int v, Node* nxt, Node* prv){
        this->next=nxt;
        this->prev=prv;
        this->value=v;
        this->is_sentinel=false;
    }

    // Return whether a node is a sentinel node 
    // Use it to check if we are at the ends of a list
   bool Node:: is_sentinel_node(){
       return is_sentinel;
    }

    // Return the value of a node
   int  Node:: get_value(){
    if(is_sentinel==false){
        return value;
    }
    else{
        return -1;
       //no value as it is a sentinel node
    }
   }