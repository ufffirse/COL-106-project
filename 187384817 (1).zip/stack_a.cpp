#include "stack_a.h"
#include<iostream>
#include<stdexcept>
/* PART A */
/* Stacks using Fixed Size Arrays */

// class Stack_A {
// private:
//     int stk[1024]; // The fixed size array
//     int size; // Number of elements in the stack

// public: 
//     // Constructor
Stack_A::Stack_A(){
        size=0;
    }

    void Stack_A::push(int data){
        if(size>=1024){
        throw std::runtime_error("Stack Full");
        }
        else{
        stk[size]=data;
        size=size+1;
        }
    }
   
    int Stack_A::pop(){
        if(size==0){
        throw std::runtime_error("Empty Stack");  
        }
        else{
        int poppedValue = stk[size - 1]; // Store the popped value
            stk[size - 1] = 0; // Clear the top element
            size = size - 1;
            return poppedValue; // Return the popped value
        }
    }

    int Stack_A::get_element_from_top(int idx){
        if (idx >= size ){
            throw std:: runtime_error("Index Out of Range");
        }
        return stk[size-idx-1];
    }
    int Stack_A::get_element_from_bottom(int idx){
        if (idx >= size ){
        throw std:: runtime_error("Index Out of Range");
        }
    return stk[idx];
    }

    void Stack_A::print_stack(bool top_or_bottom) {
    if (top_or_bottom == 0) {
        std::cout << "Elements from top: ";
        for (int i = size - 1; i >= 0; i--) {
            std::cout << stk[i] << " ";
        }
    } else {
        std::cout << "Elements from bottom: ";
        for (int j = 0; j < size; j++) {
            std::cout << stk[j] << " ";
        }
    }
    std::cout << std::endl;
}


    int Stack_A::add(){
        if(size<=1){
         throw std::runtime_error("Not Enough Arguments");
        }
    else{
        int temp=stk[size-1]+stk[size-2];
        stk[size-1]={};
        stk[size-2]=temp;
        size=size-1;
        return stk[size-1];
    }
    }

    int Stack_A::subtract(){
         if(size<=1){
         throw std::runtime_error("Not Enough Arguments");
        }
        else{
        int temp=stk[size-2]-stk[size-1];
        stk[size-1]={};
        stk[size-2]=temp;
         size=size-1;
          return stk[size-1];
        }
    }

    int Stack_A::multiply(){
         if(size<=1){
      throw std::runtime_error("Not Enough Arguments");
        }
        else{
        int temp=stk[size-1]*stk[size-2];
        stk[size-1]={};
        stk[size-2]=temp;
         size=size-1;
          return stk[size-1];
        }
    }

    int Stack_A::divide(){
        if(size<=1){
          throw std::runtime_error("Not Enough Arguments");
        }
        if(stk[size-1]==0){
           throw std::runtime_error("Divide by Zero Error");
        }
        else{
            if(stk[size-2]*stk[size-1]<0){
            if(stk[size-2]%stk[size-1]==0){
                int a=stk[size-2];
                int b=stk[size-1];
                int temp=-((-a)/b);
                stk[size-2]=temp;
                pop();
                return temp;
        }
        else{
            int a=stk[size-2];
                int b=stk[size-1];
                int temp=-((-a)/b)-1;
                stk[size-2]=temp;
                pop();
                return temp;
        }
            }
            else{
                int a=stk[size-2];
                int b=stk[size-1];
        int temp=(a/b);
        stk[size-2]=temp;
        pop();
          return temp;
        }
        }
    }
    

    int* Stack_A::get_stack(){
        int* x= stk;
        return x;
    }   

    int  Stack_A::get_size(){
     return size;
    } // Get the size of the stack



// int main(){
//     Stack_A st;
//     st.push(-1);
//     st.push(2);
//     st.divide();
//     std::cout<<*st.get_stack();
//     std::cout<<st.get_size();
//     return 0;

// }