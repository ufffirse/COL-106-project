#include"stack_b.h"
#include<iostream>
#include<stdexcept>
using namespace std;

Stack_B :: Stack_B(){
        stk=new int[1024];
        size=0;
        capacity=1024;
    }
Stack_B ::~Stack_B() {
    delete[] stk; 
}
void Stack_B ::push(int data){
        if(size==capacity-1){
        int* pt=new int[2*capacity];
         for(int i=0;i<capacity-1;i++){
            pt[i]=stk[i];
        }
        pt[capacity-1]=data;
        stk=pt;
        capacity=2*capacity;
        size=size+1;
        }
        else{
        stk[size]=data;
        size=size+1;
        }
    }

int Stack_B ::pop(){
        if(size==0){
            throw std::runtime_error("Empty Stack");  
        }
        else if(size==capacity/2 && capacity>1024){
                int* pt=new int[capacity/2];
            for(int i=0;i<(capacity/2)-1;i++){
                pt[i]=stk[i];
            }
            int popValue = stk[size - 1];
            stk=pt;
            capacity=capacity/2;
            size=size-1;
            return popValue;
        }
        else{
        int popValue = stk[size - 1]; 
            size = size - 1;
            return popValue; 
        }
    }

int Stack_B ::get_element_from_top(int idx){
        if (idx >= size ){
            throw std:: runtime_error("Index Out of Range");
        }
        return stk[size-idx-1];
    }    

int Stack_B ::get_element_from_bottom(int idx){
        if (idx >= size ){
            throw std:: runtime_error("Index Out of Range");
        }
    return stk[idx];
    }
    
int Stack_B ::get_size(){
     return size;
    } 

int Stack_B ::add(){
        if(size<=1){
         throw std::runtime_error("Not Enough Arguments1");
        }
     
    else{
        stk[size-2]=stk[size-1]+stk[size-2];
        size=size-1;
           if(size==capacity/2 && capacity>1024){
            int* pt=new int[capacity/2];
         for(int i=0;i<(capacity/2);i++){
            pt[i]=stk[i];
        }
        capacity=capacity/2;
        }
        }
        return stk[size-1];
    }

int Stack_B ::subtract(){
         if(size<=1){
         throw std::runtime_error("Not Enough Arguments2");
        }
        else{
        stk[size-2]=stk[size-2]-stk[size-1];
         size=size-1;
         if(size==capacity/2&&capacity>1024){
            int* pt=new int[capacity/2];
         for(int i=0;i<(capacity/2);i++){
            pt[i]=stk[i];
        }
        capacity=capacity/2;
        }
        }
        return stk[size-1];
    }

int Stack_B ::multiply(){
         if(size<=1){
      throw std::runtime_error("Not Enough Arguments3");
        }
        else{
        stk[size-2]=stk[size-1]*stk[size-2];
         size=size-1;
         
          if(size==capacity/2&&capacity>1024){
            int* pt=new int[capacity/2];
         for(int i=0;i<(capacity/2);i++){
            pt[i]=stk[i];
        }
        capacity=capacity/2;
        }
        }
        return stk[size-1];
    }

int Stack_B ::divide(){
         if(size<=1){
          throw std::runtime_error("Not Enough Arguments4");
        }
        if(stk[size-1]==0){
           throw std::runtime_error("Divide by Zero Error");
            return 0;
        }
        else{ 
            if(stk[size-2]*stk[size-1]<0){
            if(stk[size-2]%stk[size-1]==0){
                int a=stk[size-2];
                int b=stk[size-1];
                int temp=-((-a)/b);
                stk[size-2]=temp;
                pop();
                if(size==capacity/2&&capacity>1024){
            int* pt=new int[capacity/2];
         for(int i=0;i<(capacity/2);i++){
            pt[i]=stk[i];
        }
        capacity=capacity/2;
        
        }
                return temp;
        }
        else{
            int a=stk[size-2];
                int b=stk[size-1];
                int temp=-((-a)/b)-1;
                stk[size-2]=temp;
                pop();
                if(size==capacity/2&&capacity>1024){
            int* pt=new int[capacity/2];
         for(int i=0;i<(capacity/2);i++){
            pt[i]=stk[i];
        }
        capacity=capacity/2;
        
        }
                return temp;
        }
            }
        int temp=stk[size-2]/stk[size-1];
        stk[size-1]={};
        stk[size-2]=temp;
         size=size-1;
          if(size==capacity/2&&capacity>1024){
            int* pt=new int[capacity/2];
         for(int i=0;i<(capacity/2);i++){
            pt[i]=stk[i];
        }
        capacity=capacity/2;
        
        }
        return stk[size-1];
        }
    }

int* Stack_B ::get_stack(){
        int* x= new int[size];
        for (int i = 0; i < size; i++) {
        x[i] = stk[i];
    }
        return x;
    } 
    
    
// int main(){
//     Stack_B st;
//     st.push(-1);
//     st.push(2);
//     st.divide();
//     std::cout<<*st.get_stack();
//     std::cout<<st.get_size();
//     return 0;

// }

